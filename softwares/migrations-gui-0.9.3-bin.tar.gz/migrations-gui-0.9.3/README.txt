== Synopsis ==
This application is intended to be a more enterprise grade version of the
rails migrations. It however supports 
- Variable substituions within the migration scripts
- Multiple inter-dependent schemas
- Multiple migrations within the same database schema
- Easy to use unix and windows startup scripts


== Sample Demonstration ==
To quickly get started with the bundled sample migration you must first
startup an hsqldb instance (you must provide the hsqldb jdbc driver)

java -cp /usr/share/java/hsqldb-1.8.0.8.jar org.hsqldb.Server -database.0 file:/tmp/testdb - dbname.0 test

The /usr/share/java/hsqldb-1.8.0.8.jar is to be replaced with whichever
version of hsqldb you are using located where ever it happens to sit on your
computer.

Now simply copy the hsqldb jdbc driver to the ./lib folder.

To run the application simply type

./migration.sh


* A Graphical interface will showup. Browse to the sample-migrations/migrations.xml file.
* Choose a schema to be migrated
* Specify a version to migrate to. Leaving the version blank will migrate it to the latest definition.
* Execute and provide information as prompted (like schema username/passwords for instance).
 