delete from person where id between 1 and 4;
commit;
