delete from person where id=11;
delete from person where id=12;
delete from person where id=13;
delete from person where id=14;
commit;
