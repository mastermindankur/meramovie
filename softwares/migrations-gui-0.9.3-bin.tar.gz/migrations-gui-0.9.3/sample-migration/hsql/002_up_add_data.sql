insert into person(id, name) values(3, 'Frank 3');
insert into person(id, name) values(1, 'Frank 1');
insert into person(id, name) values(2, 'Frank 2');
insert into person(id, name) values(4, 'Frank 4');
commit;
