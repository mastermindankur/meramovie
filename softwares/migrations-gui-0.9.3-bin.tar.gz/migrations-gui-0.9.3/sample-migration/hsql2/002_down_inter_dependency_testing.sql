delete from place where id='atl';
