create table place(
id #string(36) primary key,
name #string(50),
price #number());
