insert into place(id, name, price) values('atl', 'Atlanta', '4.95');
