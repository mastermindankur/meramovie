cd `dirname $0`

JARFILES=`ls lib/*`
CLASSPATH=$CLASSPATH:.:config:`echo $JARFILES | sed s/\ /:/g`

if [ -z "$JAVA_HOME" ] ; then
  JAVA_CMD=java
else
  JAVA_CMD=$JAVA_HOME/bin/java
fi

$JAVA_CMD -Xmx32m -Dcom.sun.management.jmxremote -cp $CLASSPATH org.inigma.migrations.swing.Main $1 $2 $3 $4 $5 $6 $7 $8 $9
cd -
